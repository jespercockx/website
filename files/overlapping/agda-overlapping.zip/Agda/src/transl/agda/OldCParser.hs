{-# OPTIONS -cpp #-}

#undef NEWSYNTAX

module OldCParser where

#include "CParser.hs"
