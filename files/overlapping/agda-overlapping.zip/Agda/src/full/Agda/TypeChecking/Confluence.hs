{-# LANGUAGE TupleSections, PatternGuards #-}

module Agda.TypeChecking.Confluence where

import Data.Foldable (forM_)
import Data.Monoid
import qualified Data.Set as Set
import Data.Set (Set)

import Agda.Syntax.Common
import Agda.Syntax.Internal
import qualified Agda.Syntax.Info as Info
import qualified Agda.Syntax.Abstract as A
import Agda.TypeChecking.Monad
import Agda.TypeChecking.Reduce
import Agda.TypeChecking.Substitute

import Agda.Utils.Impossible
#include "../undefined.h"

data Overlap = Overlap Term Term | NoOverlap | DontKnow Pattern Pattern 
  deriving (Show)
           
data Dot = DotBody Term | BindDot (Abs Dot)
  deriving (Show)

type Dots = [Maybe Dot]

instance Apply Dot where
  apply b [] = b
  apply (BindDot abs) (a:args) = absApp abs (unArg a) `apply` args                             
  apply (DotBody v) args = DotBody $ v `apply` args

instance Subst Dot where
  applySubst rho (DotBody t) = DotBody $ applySubst rho t
  applySubst rho (BindDot b) = BindDot $ applySubst rho b 
  
bindBody :: String -> ClauseBody -> ClauseBody
bindBody x = Bind . (Abs x)

bindBody_ :: ClauseBody -> ClauseBody
bindBody_ = bindBody "_"

bindDots :: String -> Dots -> Dots
bindDots x = (map . fmap) (BindDot . (Abs x))

bindDots_ :: Dots -> Dots
bindDots_ = bindDots "_"
  
-- replaceVar i k dots: replaces the i'th variable by k fresh variables
replaceVar :: Int -> Int -> Dots -> Dots
replaceVar 0 k (Nothing:dots) = (replicate k Nothing) ++ dots 
replaceVar 0 k ((Just _):dots)  = __IMPOSSIBLE__
  -- ^ cannot replace dot
replaceVar n k (dot:dots) = dot:(replaceVar (n-1) k dots)
replaceVar _ _ _ = __IMPOSSIBLE__

-- getDots [] ps: Get a list of all dots in ps in reversed order
getDots :: [Maybe Term] -> [Arg Pattern] -> (Int, Dots)
getDots dots [] = (0, (map . fmap) DotBody dots)
getDots dots (p:ps)
  = case unArg p of
      VarP x -> let (n, ds) = getDots (Nothing:dots) ps in
        (n+1, bindDots x ds) 
      DotP d -> let (n, ds) = getDots ((Just d):dots) ps in
        (n+1, bindDots_ ds)
      ConP c _ args -> getDots dots (args ++ ps)
      LitP lit -> getDots dots ps
      
clauseInfo :: Clause -> (Int, [Arg Pattern], Dots, ClauseBody)
clauseInfo cl = let (n, dots) = getDots [] (clausePats cl) in
  (n, clausePats cl, dots, clauseBody cl)
      
getOverlap :: (Int, [Arg Pattern], Dots, ClauseBody) 
           -> (Int, [Arg Pattern], Dots, ClauseBody) 
           -> TCM Overlap
getOverlap (0, [], _, NoBody) (0, [], _, _) = return NoOverlap
getOverlap (0, [], _, _) (0, [], _, NoBody) = return NoOverlap
getOverlap (0, [], dots1, Body rhs1) (0, [], dots2, Body rhs2) 
  = handleDots 0 (dots1, rhs1) (dots2, rhs2)
getOverlap (n1, p1:pats1, dots1, body1) (n2, p2:pats2, dots2, body2)
  = case (unArg p1, unArg p2) of
      (ConP c1 _ args1, ConP c2 _ args2) 
        | c1 == c2  -> getOverlap 
                         (n1, args1 ++ pats1, dots1, body1) 
                         (n2, args2 ++ pats2, dots2, body2)
        | otherwise -> return NoOverlap 
      (LitP lit1, LitP lit2)                 
        | lit1 == lit2 -> getOverlap (n1, pats1, dots1, body1) (n2, pats2, dots2, body2)
        | otherwise    -> return NoOverlap
        -- TODO: compare compare constructors and literals
      (ConP c1 _ args1, VarP x2) ->                  
        let k = length args1
            t = Con c1 $ map (defaultArg . var) (downFrom (k-1))         
            -- ^ apply constructor to fresh vars
            (dots2', body2') = if k>0 then raise (k-1) (dots2, body2) else (dots2, body2) 
            -- ^ make place for new variables
            body2'' = directSubst 0 t (unBind body2')
            dots2'' = directSubst 0 t (unBindDots dots2')
            -- ^ substitute
            (dots2''', body2''') = (ntimes k bindDots_ dots2'', ntimes k bindBody_ body2'') 
            -- ^ bind new vars
            (dots2'''', body2'''') = if k==0 then raise (-1) (dots2''', body2''') else (dots2''', body2''')
            dots2''''' = replaceVar (n2-1) k dots2''''
            -- ^ update dots
        in
            getOverlap (n1, args1 ++ pats1, dots1, body1)
                       (n2 + (k-1), (replicate k (defaultArg (VarP "_"))) ++ pats2, 
                         dots2''''', body2'''')
      (VarP x1, ConP c2 _ args2) ->                  
        let k = length args2
            t = Con c2 $ map (defaultArg . var) (downFrom (k-1))         
            -- ^ apply constructor to fresh vars
            (dots1', body1') = if k>0 then raise (k-1) (dots1, body1) else (dots1, body1) 
            -- ^ make place for new variables
            body1'' = directSubst 0 t (unBind body1')
            dots1'' = directSubst 0 t (unBindDots dots1')
            -- ^ substitute
            (dots1''', body1''') = (ntimes k bindDots_ dots1'', ntimes k bindBody_ body1'') 
            -- ^ bind new vars
            (dots1'''', body1'''') = if k==0 then raise (-1) (dots1''', body1''') else (dots1''', body1''')
            dots1''''' = replaceVar (n1-1) k dots1''''
            -- ^ update dots
        in
            getOverlap (n1 + (k-1), (replicate k (defaultArg (VarP "_"))) ++ pats1, 
                         dots1''''', body1'''')
                       (n2, args2 ++ pats2, dots2, body2)        
      (VarP x1, VarP x2) -> getOverlap (n1-1, pats1, unBindDots dots1, unBind body1)
                                       (n2-1, pats2, unBindDots dots2, unBind body2)
      (DotP x1, VarP x2) -> getOverlap (n1-1, pats1, unBindDots dots1, unBind body1)
                                       (n2-1, pats2, unBindDots dots2, unBind body2)
      (VarP x1, DotP x2) -> getOverlap (n1-1, pats1, unBindDots dots1, unBind body1)
                                       (n2-1, pats2, unBindDots dots2, unBind body2)  
      (DotP x1, DotP x2) -> getOverlap (n1-1, pats1, unBindDots dots1, unBind body1)
                                       (n2-1, pats2, unBindDots dots2, unBind body2)
      (p1', p2') -> if conflict pats1 pats2 then return NoOverlap else return (DontKnow p1' p2')
    where    
      unBind :: ClauseBody -> ClauseBody
      unBind (Bind abs) = absBody abs
      unBind _ = __IMPOSSIBLE__
      
      unBindDot :: Dot -> Dot
      unBindDot (BindDot abs) = absBody abs
      unBindDot _ = __IMPOSSIBLE__
      
      unBindDots :: Dots -> Dots
      unBindDots = (map . fmap) unBindDot
      
      downFrom :: Int -> [Int]
      downFrom n | n < 0     = []
                 | otherwise = n : (downFrom (n-1))
                               
      ntimes :: Int -> (a -> a) -> a -> a
      ntimes n f x
       | n > 0     = ntimes (n-1) f (f x)
       | otherwise = x
getOverlap x y = error $ "getOverlap   " ++ show x ++ "   " ++ show y 

handleDots :: Int -> (Dots, Term) -> (Dots, Term) -> TCM Overlap
handleDots _ ([], rhs1) ([],  rhs2) = return $ Overlap rhs1 rhs2
handleDots n (dot1:dots1, rhs1) (dot2:dots2, rhs2) 
  = case (dot1, dot2) of
      (Nothing, Nothing) -> handleDots (n+1) (dots1, rhs1) (dots2, rhs2) 
      (Just (DotBody t1), Nothing) -> handleDots (n+1) (dots1, rhs1) (directSubst n t1 (dots2, rhs2))
      (Nothing, Just (DotBody t2)) -> handleDots (n+1) (directSubst n t2 (dots1, rhs1)) (dots2, rhs2)
      (Just (DotBody t1), Just (DotBody t2)) -> do
        (t1', t2') <- normalise =<< instantiateFull (t1, t2)                    
        case equalTerm t1' t2' of
          Equal -> handleDots (n+1) (dots1, rhs1) (dots2, rhs2)
          _     -> return $ DontKnow (DotP t1) (DotP t2)
      (_, _) -> __IMPOSSIBLE__
      -- ^ All abstractions should be stripped by now
handleDots n x y = error $ "handleDots " ++ show n ++ "   " ++ show x ++ "   " ++ show y
                                     
conflict :: [Arg Pattern] -> [Arg Pattern] -> Bool
conflict [] [] = False
conflict (p1:pats1) (p2:pats2) = case (unArg p1, unArg p2) of
  (VarP _ , _) -> conflict pats1 pats2
  (_ , VarP _) -> conflict pats1 pats2
  (ConP c1 _ args1 , ConP c2 _ args2) ->
    if c1 == c2
    then conflict (args1 ++ pats1) (args2 ++ pats2)   
    else True     
  (LitP lit1 , LitP lit2) ->
    if lit1 == lit2
    then conflict pats1 pats2   
    else True     
  (_ , _) -> conflict pats1 pats2
conflict _ _ = __IMPOSSIBLE__

checkOverlap :: Overlap -> TCM ()
checkOverlap (Overlap t1 t2) = do
  (t1', t2') <- normalise =<< instantiateFull (t1, t2)
  case equalTerm t1' t2' of 
    Equal -> return () 
    Unequal u1 u2 -> typeError $ OverlappingNotConfluent u1 u2
    BlockedByMeta m -> return () -- TODO: give a warning
checkOverlap NoOverlap = return ()
checkOverlap (DontKnow p1 p2)  = typeError $ CantFindOverlap p1 p2

checkConfluence :: [Clause] -> TCM ()
checkConfluence cls = do 
  let pairs = unequalPairs cls
  forM_ pairs $ \(c1, c2) -> do 
    reportSLn "tc.overlapping" 0 "Checking overlap:"
    reportSLn "tc.overlapping" 0 $ show c1
    reportSLn "tc.overlapping" 0 $ show c2
    let info1 = clauseInfo c1
        info2 = clauseInfo c2
    overlap <- getOverlap info1 info2
    reportSLn "tc.overlapping" 0 $ show overlap
    checkOverlap overlap
  where
    unequalPairs :: [a] -> [(a,a)]
    unequalPairs [] = []
    unequalPairs (x:xs) = (map (x,) xs) ++ unequalPairs xs
    
data Equal = Equal | Unequal Term Term | BlockedByMeta MetaId

instance Monoid Equal where
  mempty = Equal
  (Unequal t1 t2) `mappend` _ = Unequal t1 t2
  (BlockedByMeta m) `mappend` (Unequal t1 t2) = Unequal t1 t2
  (BlockedByMeta m) `mappend` _ = BlockedByMeta m  
  Equal `mappend` e = e
  
equalTerm :: Term -> Term -> Equal
equalTerm (Var n1 args1) (Var n2 args2) 
 | n1 == n2  = equalArgs args1 args2
 | otherwise = Unequal (Var n1 []) (Var n2 [])
equalTerm (Lam _ abs1) (Lam _ abs2) = equalTerm (absBody abs1) (absBody abs2)
equalTerm (Lit lit1) (Lit lit2)
 | lit1 == lit2 = Equal
 | otherwise    = Unequal (Lit lit1) (Lit lit2)
equalTerm (Def f1 args1) (Def f2 args2) 
 | f1 == f2  = equalArgs args1 args2
 | otherwise = Unequal (Def f1 []) (Def f2 [])
equalTerm (Con c1 args1) (Con c2 args2)
 | c1 == c2  = equalArgs args1 args2 
 | otherwise = Unequal (Con c1 []) (Con c2 [])
equalTerm (MetaV id args) _ = BlockedByMeta id
equalTerm _ (MetaV id args) = BlockedByMeta id
equalTerm t1 t2 
 | t1 == t2  = Equal
 | otherwise = Unequal t1 t2

equalArgs :: Args -> Args -> Equal
equalArgs args1 args2 = mconcat $ zipWith equalTerm (map unArg args1) (map unArg args2) 

checkDefConfluence :: QName -> TCM ()
checkDefConfluence x = do
  info <- getConstInfo x
  case theDef info of
    f@Function{funClauses = cls}
     | isOverlapping f -> checkConfluence cls
    _ -> return ()

checkMutualConfluence :: Info.MutualInfo -> [A.Declaration] -> TCM ()
checkMutualConfluence i ds = if null names then return () else 
  traceCall (SetRange (Info.mutualRange i)) $ do
    mutualBlock <- findMutualBlock (head names)
    let allnames = Set.elems mutualBlock
    forM_ allnames checkDefConfluence                           
                                  
  where
    getName (A.FunDef i x delayed o cs) = [x]
    getName (A.RecDef _ _ _ _ _ _ ds) = concatMap getName ds
    getName (A.Mutual _ ds)       = concatMap getName ds
    getName (A.Section _ _ _ ds)  = concatMap getName ds
    getName (A.ScopedDecl _ ds)   = concatMap getName ds
    getName _                     = []

    names = concatMap getName ds
    
checkDeclConfluence :: A.Declaration -> TCM ()
checkDeclConfluence (A.ScopedDecl scope ds) = do
  setScope scope
  checkDeclsConfluence ds
checkDeclConfluence d = case d of
    A.Mutual _ ds
      | [A.RecSig{}, A.RecDef _ r _ _ _ _ rds] <- unscopeDefs ds
                       -> checkRecDef ds r rds
    A.Mutual i ds      -> checkMutualConfluence i ds
    A.Section _ x _ ds -> checkSectionConfluence x ds
    _                  -> return ()
  where
      setScopeFromDefs = mapM_ setScopeFromDef
      setScopeFromDef (A.ScopedDecl scope d) = setScope scope
      setScopeFromDef _ = return ()

      unscopeDefs = concatMap unscopeDef

      unscopeDef (A.ScopedDecl _ ds) = unscopeDefs ds
      unscopeDef d = [d]
      
      checkRecDef ds r rds = do
        setScopeFromDefs ds
        checkSectionConfluence (mnameFromList $ qnameToList r) rds
  
checkDeclsConfluence :: [A.Declaration] -> TCM ()
checkDeclsConfluence ds = forM_ ds checkDeclConfluence
  
checkSectionConfluence :: ModuleName -> [A.Declaration] -> TCM ()
checkSectionConfluence x ds = do
  tel <- lookupSection x
  withCurrentModule x $ addCtxTel tel $ checkDeclsConfluence ds
