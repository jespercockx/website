{-# LANGUAGE CPP, PatternGuards,
             TypeSynonymInstances, FlexibleInstances #-}

module Agda.TypeChecking.Overlapping where

import Prelude hiding (mapM)
import Control.Monad.State hiding (mapM)
import Control.Monad.Reader hiding (mapM)
import Control.Monad.Error hiding (mapM)
import Control.Applicative
import Data.List as List hiding (sort)
import qualified Data.Map as Map
import Data.Map (Map)
import qualified Data.Set as Set
import Data.Traversable
import Data.Hashable

import Agda.Syntax.Position
import Agda.Syntax.Common
import Agda.Syntax.Internal
import Agda.Syntax.Scope.Base (Scope)
import Agda.Syntax.Literal

import Agda.TypeChecking.Monad
import Agda.TypeChecking.Monad.Context
import Agda.TypeChecking.Monad.Builtin
import Agda.TypeChecking.Substitute
import Agda.TypeChecking.Free
import Agda.TypeChecking.EtaContract
import Agda.TypeChecking.CompiledClause

import {-# SOURCE #-} Agda.TypeChecking.Patterns.Match
import {-# SOURCE #-} Agda.TypeChecking.CompiledClause.Match

import Agda.Utils.Monad
import Agda.Utils.HashMap (HashMap)
import qualified Agda.Utils.HashMap as HMap

#include "../undefined.h"
import Agda.Utils.Impossible

appDef :: Term -> CompiledClauses -> MaybeReducedArgs -> TCM (Reduced (Blocked Term) Term)
appDef v cc args = liftTCM $ do
  r <- matchCompiled cc args
  case r of
    YesReduction t    -> return $ YesReduction t
    NoReduction args' -> return $ NoReduction $ fmap (apply v) args'

appDef' :: Term -> [Clause] -> MaybeReducedArgs -> TCM (Reduced (Blocked Term) Term)
appDef' _ [] _ = {- ' -} __IMPOSSIBLE__
appDef' v cls@(Clause {clausePats = ps} : _) args
  | m < n     = return $ NoReduction $ notBlocked $ v `apply` map ignoreReduced args
  | otherwise = do
    let (args0, args1) = splitAt n args
    matches <- mapM (getMatch (map ignoreReduced args0)) cls
    let (m , body , args) = foldr1 choose matches
    r <- case m of
            No		      -> typeError $ IncompletePatternMatching v args
            DontKnow Nothing  -> return $ NoReduction $ notBlocked $ v `apply` args
            DontKnow (Just m) -> return $ NoReduction $ blocked m $ v `apply` args
            Yes args'
              | hasBody body  -> return $ YesReduction (app args' body)
              | otherwise     -> return $ NoReduction $ notBlocked $ v `apply` args
    case r of
      YesReduction u -> return $ YesReduction $ u `apply` map ignoreReduced args1
      NoReduction v  -> return $ NoReduction $ (`apply` map ignoreReduced args1) <$> v
  where

    n = genericLength ps
    m = genericLength args

    getMatch :: Args -> Clause -> TCM (Match , ClauseBody , Args)
    getMatch args (Clause { clausePats = pats , clauseBody = body}) = do
      (match , args) <- matchPatterns pats args
      return (match , body , args)
                                     
    -- Determine which clause gives the best (most definite) match
    choose :: (Match, ClauseBody, Args) -> (Match, ClauseBody, Args) -> (Match, ClauseBody, Args)
    choose a@(Yes us, _, _)            _                           = a
    choose _                           b@(Yes vs, _, _)            = b 
    choose a@(DontKnow (Just m), _, _) _                           = a 
    choose _                           b@(DontKnow (Just m), _, _) = b
    choose a@(DontKnow Nothing, _, _)  _                           = a
    choose _                           b@(DontKnow Nothing, _ , _) = b
    choose a@(No, _, _)                b@(No, _, _)                = a

    hasBody (Body _) = True
    hasBody NoBody   = False
    hasBody (Bind b) = hasBody (unAbs b)

    app []		 (Body v') = v'
    app (arg : args) (Bind b)  = app args $ absApp b arg -- CBN
    app  _		  NoBody   = __IMPOSSIBLE__
    app (_ : _)	 (Body _)  = __IMPOSSIBLE__
    app []		 (Bind _)  = __IMPOSSIBLE__
