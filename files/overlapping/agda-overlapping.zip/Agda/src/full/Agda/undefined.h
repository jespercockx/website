#define __IMPOSSIBLE__ (throwImpossible (Impossible __FILE__ __LINE__))
#define __IMPOSSIBLE_TERM__ (impossibleTerm __FILE__ __LINE__)
