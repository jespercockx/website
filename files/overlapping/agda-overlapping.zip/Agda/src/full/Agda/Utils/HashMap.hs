
module Agda.Utils.HashMap
  ( module HashMap ) where

import Data.HashMap.Strict as HashMap

