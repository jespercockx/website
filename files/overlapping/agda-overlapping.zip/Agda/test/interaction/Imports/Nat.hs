module Imports.Nat where

data Nat = Zero | Suc Nat
